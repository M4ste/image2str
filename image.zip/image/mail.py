import os
import sys

print sys.argv[1]

#tesseract.exe 6.png 1 -l eng -psm 6
os.system("img2str.exe %s temp -l eng -psm 6"%(sys.argv[1]))

f = open('./temp.txt','r')
str=f.read()

res=str.replace(" . ",".")

print("\n------------result-------------\n")

print res

print("\n-------------------------------")
